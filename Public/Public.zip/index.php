<?php

session_start();

require '../App/Core/bootstrap.php';

